package com.example.pclauncher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val CYAN = 0xFF00E5FF.toInt()
private val MAGENTA = 0xFFFF2BD6.toInt()
private val TEXT = 0xFFB8F3FF.toInt()
private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

/** Latar cyberpunk: gradasi hitam -> biru malam, glow neon, grid perspektif. */
class CyberBackground(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val hz = h * 0.60f

        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF000000.toInt(), 0xFF050A24.toInt(), 0xFF0B1550.toInt(), 0xFF020412.toInt()),
            floatArrayOf(0f, 0.45f, 0.62f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)

        p.shader = RadialGradient(
            w / 2, hz, w * 0.8f,
            intArrayOf(alpha(MAGENTA, 0x77), alpha(CYAN, 0x28), 0x00000000),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, hz - h * 0.3f, w, hz + h * 0.3f, p)
        p.shader = null

        // grid perspektif
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f
        p.color = alpha(CYAN, 0x50)
        for (i in 1..14) {
            val t = i / 14f
            val y = hz + (h - hz) * t * t
            c.drawLine(0f, y, w, y, p)
        }
        for (k in -14..14) {
            c.drawLine(w / 2 + k * 8f, hz, w / 2 + k * w * 0.16f, h, p)
        }
        // garis horizon neon
        p.strokeWidth = 3f
        p.color = alpha(MAGENTA, 0xE0)
        c.drawLine(0f, hz, w, hz, p)
    }
}

class MainActivity : Activity() {

    data class AppItem(val label: String, val pkg: String, val icon: Drawable)

    private var apps = listOf<AppItem>()
    private lateinit var startMenu: LinearLayout
    private lateinit var menuAdapter: AppAdapter
    private lateinit var clockTime: TextView
    private lateinit var clockDate: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int, radius: Int, strokeW: Int = 1) =
        GradientDrawable().apply {
            setColor(fill); setStroke(dp(strokeW), stroke); cornerRadius = dp(radius).toFloat()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        apps = loadApps()

        val root = FrameLayout(this)
        root.addView(CyberBackground(this), FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // Ikon desktop
        val grid = GridView(this).apply {
            numColumns = 4
            adapter = AppAdapter(apps.take(20), false)
            verticalSpacing = dp(6)
            setPadding(dp(8), dp(16), dp(8), dp(8))
            selector = ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos]) }
        }
        root.addView(grid, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT).apply {
            bottomMargin = dp(50)
        })

        // Start menu
        menuAdapter = AppAdapter(apps, true)
        val header = TextView(this).apply {
            text = "// APPLICATIONS"
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            textSize = 13f
            setTextColor(MAGENTA)
            setShadowLayer(10f, 0f, 0f, MAGENTA)
            setPadding(dp(4), 0, 0, dp(8))
        }
        val search = EditText(this).apply {
            hint = "> cari aplikasi_"
            typeface = Typeface.MONOSPACE
            setHintTextColor(alpha(CYAN, 0x80))
            setTextColor(CYAN)
            textSize = 14f
            setSingleLine()
            background = box(alpha(0x000000, 0x00), alpha(CYAN, 0xAA), 6)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    val q = s.toString().trim().lowercase()
                    menuAdapter.items = apps.filter { it.label.lowercase().contains(q) }
                    menuAdapter.notifyDataSetChanged()
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        val list = ListView(this).apply {
            adapter = menuAdapter
            divider = null
            selector = ColorDrawable(alpha(CYAN, 0x30))
            setOnItemClickListener { _, _, pos, _ -> launch(menuAdapter.items[pos]) }
        }
        startMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = box(0xF205070F.toInt(), alpha(CYAN, 0xDD), 10, 2)
            addView(header)
            addView(search, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8) })
            addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }
        root.addView(startMenu, FrameLayout.LayoutParams(dp(330), dp(470),
            Gravity.BOTTOM or Gravity.START).apply {
            bottomMargin = dp(58); leftMargin = dp(8)
        })

        // Taskbar
        val startBtn = TextView(this).apply {
            text = "◢ START"
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            textSize = 14f
            setTextColor(CYAN)
            setShadowLayer(10f, 0f, 0f, CYAN)
            gravity = Gravity.CENTER
            background = box(alpha(CYAN, 0x22), CYAN, 6)
            setPadding(dp(18), 0, dp(18), 0)
            setOnClickListener { toggleMenu() }
        }
        clockTime = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            textSize = 14f
            setTextColor(CYAN)
            setShadowLayer(8f, 0f, 0f, CYAN)
            gravity = Gravity.END
        }
        clockDate = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 10f
            setTextColor(MAGENTA)
            gravity = Gravity.END
        }
        val clockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setPadding(dp(12), 0, dp(14), 0)
            addView(clockTime)
            addView(clockDate)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xF2000000.toInt())
            addView(startBtn, LinearLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT).apply {
                setMargins(dp(8), dp(6), 0, dp(6))
            })
            addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
            addView(clockBox, LinearLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT))
        }
        val neonLine = View(this).apply { setBackgroundColor(alpha(MAGENTA, 0xFF)) }
        val taskbar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(neonLine, LinearLayout.LayoutParams(MATCH_PARENT, dp(2)))
            addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(48)))
        }
        root.addView(taskbar, FrameLayout.LayoutParams(MATCH_PARENT, dp(50), Gravity.BOTTOM))

        setContentView(root)
        tick()
    }

    private fun tick() {
        val now = Date()
        clockTime.text = timeFmt.format(now)
        clockDate.text = dateFmt.format(now)
        handler.postDelayed({ tick() }, 15_000)
    }

    private fun toggleMenu() {
        startMenu.visibility = if (startMenu.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun launch(app: AppItem) {
        startMenu.visibility = View.GONE
        packageManager.getLaunchIntentForPackage(app.pkg)?.let { startActivity(it) }
    }

    private fun loadApps(): List<AppItem> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName, it.loadIcon(packageManager)) }
            .sortedBy { it.label.lowercase() }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        startMenu.visibility = View.GONE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        startMenu.visibility = View.GONE
    }

    inner class AppAdapter(var items: List<AppItem>, private val horizontal: Boolean) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()

        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val app = items[p]
            val ctx = this@MainActivity
            val row = LinearLayout(ctx).apply {
                orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
                gravity = if (horizontal) Gravity.CENTER_VERTICAL else Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
            }
            val tileSize = dp(if (horizontal) 44 else 62)
            val iconTile = FrameLayout(ctx).apply {
                background = box(alpha(0x0A0F24, 0xB0), alpha(if (horizontal) CYAN else MAGENTA, 0x90), 14)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                addView(ImageView(ctx).apply { setImageDrawable(app.icon) },
                    FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            }
            row.addView(iconTile, LinearLayout.LayoutParams(tileSize, tileSize))
            row.addView(TextView(ctx).apply {
                text = app.label
                typeface = Typeface.MONOSPACE
                setTextColor(TEXT)
                textSize = if (horizontal) 14f else 11f
                maxLines = if (horizontal) 1 else 2
                ellipsize = TextUtils.TruncateAt.END
                gravity = if (horizontal) Gravity.START else Gravity.CENTER
                setShadowLayer(8f, 0f, 0f, if (horizontal) Color.TRANSPARENT else CYAN)
                setPadding(if (horizontal) dp(12) else 0, if (horizontal) 0 else dp(5), 0, 0)
            })
            return row
        }
    }
}
