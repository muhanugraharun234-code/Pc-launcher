CARA BUILD APK
1. Install Android Studio, lalu File > Open > pilih folder PCLauncher.
2. Tunggu Gradle sync selesai.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK ada di app/build/outputs/apk/debug/app-debug.apk
5. Install di HP/tablet, tekan tombol Home, pilih "PC Launcher" > Always.
